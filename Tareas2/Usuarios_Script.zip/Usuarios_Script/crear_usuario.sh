#!/bin/bash

# Nombre del script : crear_usuario.sh

# SECCION 1: DEFINICION DE VARIABLES

USUARIO="$1"                 # Nombre del usuario: primer parametro recibido
CARPETAS=("TC" "T" "P")      # Arreglo con los nombres de las carpetas a crear
ERRORES=0                    # Contador de errores detectados al verificar

# SECCION 2: VERIFICACION DE PRIVILEGIOS ADMINISTRATIVOS
# Variable utilizada: EUID (ID efectivo del usuario que ejecuta el script).
# Manejo de errores: si no es root, se muestra mensaje y se sale con codigo 1.

if [ "$EUID" -ne 0 ]; then
    echo "[ERROR] Este script requiere privilegios administrativos."
    echo "        Ejecutelo con: sudo $0 [nombre_usuario]"
    exit 1
fi
echo "[OK] Privilegios administrativos verificados."

# SECCION 3: OBTENCION DEL NOMBRE DE USUARIO
# Validacion: se comprueba que el nombre no este vacio (-z) y que cumpla un
#             formato valido de Linux (minusculas, numeros, guion y guion bajo,
#             iniciando con letra o guion bajo, maximo 32 caracteres).
# Si no se recibio parametro, se solicita al usuario por teclado

if [ -z "$USUARIO" ]; then
    read -p "Ingrese el nombre del usuario a crear: " USUARIO
fi

# Validacion 1: el nombre no debe quedar vacio
if [ -z "$USUARIO" ]; then
    echo "[ERROR] No se ingreso ningun nombre de usuario."
    exit 1
fi

# Validacion 2: el nombre debe cumplir el formato valido para Linux
# (expresion regular evaluada con =~ dentro de [[ ]])
if [[ ! "$USUARIO" =~ ^[a-z_][a-z0-9_-]{0,31}$ ]]; then
    echo "[ERROR] Nombre de usuario invalido: '$USUARIO'."
    echo "        Use minusculas, numeros, '-' o '_', iniciando con letra o '_'."
    exit 1
fi

# SECCION 4: VERIFICACION PREVIA DE EXISTENCIA
# Comando: 'id' regresa codigo 0 si el usuario existe; se redirige la salida
#          a /dev/null para no mostrar texto innecesario.
# Manejo de errores: si ya existe, se informa y se termina el script.

if id "$USUARIO" &>/dev/null; then
    echo "[ERROR] El usuario '$USUARIO' ya existe en el sistema."
    exit 1
fi

# SECCION 5: CREACION DEL USUARIO
# Comando: useradd -m  -> crea tambien el directorio HOME (/home/usuario)
#                  -s /bin/bash -> asigna Bash como shell de inicio de sesion
# Manejo de errores: se revisa el codigo de salida ($?) del comando.

echo "[INFO] Creando el usuario '$USUARIO'..."
useradd -m -s /bin/bash "$USUARIO"

if [ $? -ne 0 ]; then
    echo "[ERROR] No fue posible crear el usuario '$USUARIO'."
    exit 1
fi

# SECCION 6: VALIDACION DE LA CREACION DEL USUARIO
# Comandos: 'id' (consulta UID/GID) y 'getent passwd' (consulta /etc/passwd).
# Variable utilizada: HOME_USUARIO, se obtiene del 6to campo de /etc/passwd.

if id "$USUARIO" &>/dev/null && getent passwd "$USUARIO" &>/dev/null; then
    echo "[OK] El usuario '$USUARIO' fue creado y existe en el sistema."
    echo "     Datos del usuario: $(id "$USUARIO")"
    echo "     Registro en passwd: $(getent passwd "$USUARIO")"
else
    echo "[ERROR] El usuario '$USUARIO' no se encontro despues de crearlo."
    exit 1
fi

# Se obtiene la ruta real del HOME del usuario desde /etc/passwd
HOME_USUARIO=$(getent passwd "$USUARIO" | cut -d: -f6)
echo "[INFO] Directorio HOME del usuario: $HOME_USUARIO"

# SECCION 7: CREACION DE LA ESTRUCTURA DE DIRECTORIOS
# Comandos: mkdir -> crea la carpeta
#           chown -> asigna al usuario como propietario (el script corre como
#                    root, por lo que sin esto las carpetas serian de root)
# Estructura de control: ciclo 'for' que recorre el arreglo CARPETAS.
# Manejo de errores: si mkdir falla, se muestra el error y se suma al contador.

echo "[INFO] Creando estructura de directorios..."
for CARPETA in "${CARPETAS[@]}"; do
    mkdir "$HOME_USUARIO/$CARPETA"
    if [ $? -eq 0 ]; then
        # Se cambia el propietario y grupo de la carpeta al nuevo usuario
        chown "$USUARIO":"$USUARIO" "$HOME_USUARIO/$CARPETA"
        echo "     [OK] Carpeta '$CARPETA' creada."
    else
        echo "     [ERROR] No se pudo crear la carpeta '$CARPETA'."
        ERRORES=$((ERRORES + 1))
    fi
done

# SECCION 8: VERIFICACION DE LAS CARPETAS
# Validacion: la prueba '-d' evalua si la ruta existe y es un directorio.

echo "[INFO] Verificando carpetas creadas..."
for CARPETA in "${CARPETAS[@]}"; do
    if [ -d "$HOME_USUARIO/$CARPETA" ]; then
        echo "     [OK] Verificado: $HOME_USUARIO/$CARPETA existe."
    else
        echo "     [ERROR] No existe: $HOME_USUARIO/$CARPETA"
        ERRORES=$((ERRORES + 1))
    fi
done

# Se muestra el contenido del HOME como evidencia (-l lista detallada, -d nada)
echo "[INFO] Contenido del HOME de '$USUARIO':"
ls -l "$HOME_USUARIO"

# SECCION 9: RESULTADO FINAL
# Manejo de errores: codigo de salida 0 si todo salio bien, 1 si hubo errores.

if [ "$ERRORES" -eq 0 ]; then
    echo "[EXITO] Proceso completado: usuario '$USUARIO' y carpetas TC, T y P creados."
    exit 0
else
    echo "[ERROR] El proceso termino con $ERRORES error(es). Revise los mensajes."
    exit 1
fi
